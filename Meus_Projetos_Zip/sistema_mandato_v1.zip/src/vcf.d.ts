declare module 'vcf';
